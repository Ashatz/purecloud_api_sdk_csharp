---
title: EdgeVersionInformation
---
## ININ.PureCloudApi.Model.EdgeVersionInformation

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **SoftwareVersion** | **string** |  | [optional] |
{: class="table table-striped"}


