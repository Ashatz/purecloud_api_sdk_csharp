---
title: EdgeAutoUpdateConfig
---
## ININ.PureCloudApi.Model.EdgeAutoUpdateConfig

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **TimeZone** | **string** |  | [optional] |
| **Rrule** | **string** |  | [optional] |
| **Start** | **DateTime?** | Date time is represented as an ISO-8601 string. For example: yyyy-MM-ddTHH:mm:ss.SSSZ | [optional] |
| **End** | **DateTime?** | Date time is represented as an ISO-8601 string. For example: yyyy-MM-ddTHH:mm:ss.SSSZ | [optional] |
{: class="table table-striped"}


