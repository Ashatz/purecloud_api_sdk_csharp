---
title: FavoriteTemplateRequestData
---
## ININ.PureCloudApi.Model.FavoriteTemplateRequestData

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **TemplateId** | **string** |  | [optional] |
{: class="table table-striped"}


