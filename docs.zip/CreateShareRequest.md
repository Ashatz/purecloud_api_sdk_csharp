---
title: CreateShareRequest
---
## ININ.PureCloudApi.Model.CreateShareRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **SharedEntityType** | **string** |  | [optional] |
| **SharedEntity** | [**SharedEntity**](SharedEntity.html) |  | [optional] |
| **MemberType** | **string** |  | [optional] |
| **Member** | [**SharedEntity**](SharedEntity.html) |  | [optional] |
| **Members** | [**List&lt;CreateShareRequestMember&gt;**](CreateShareRequestMember.html) |  | [optional] |
{: class="table table-striped"}


