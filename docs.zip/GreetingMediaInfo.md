---
title: GreetingMediaInfo
---
## ININ.PureCloudApi.Model.GreetingMediaInfo

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **MediaFileUri** | **string** |  | [optional] |
| **MediaImageUri** | **string** |  | [optional] |
{: class="table table-striped"}


