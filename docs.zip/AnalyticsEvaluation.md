---
title: AnalyticsEvaluation
---
## ININ.PureCloudApi.Model.AnalyticsEvaluation

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **EvaluationId** | **string** |  | [optional] |
| **EvaluatorId** | **string** |  | [optional] |
| **UserId** | **string** |  | [optional] |
| **EventTime** | **string** |  | [optional] |
| **QueueId** | **string** |  | [optional] |
| **FormId** | **string** |  | [optional] |
| **ContextId** | **string** |  | [optional] |
| **FormName** | **string** |  | [optional] |
| **GetoTotalScore** | **long?** |  | [optional] |
| **GetoTotalCriticalScore** | **long?** |  | [optional] |
{: class="table table-striped"}


