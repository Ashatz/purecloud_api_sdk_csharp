---
title: AggregateMetricData
---
## ININ.PureCloudApi.Model.AggregateMetricData

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Metric** | **string** |  | [optional] |
| **Qualifier** | **string** |  | [optional] |
| **Stats** | [**StatisticalSummary**](StatisticalSummary.html) |  | [optional] |
{: class="table table-striped"}


