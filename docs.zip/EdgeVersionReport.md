---
title: EdgeVersionReport
---
## ININ.PureCloudApi.Model.EdgeVersionReport

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **OldestVersion** | [**EdgeVersionInformation**](EdgeVersionInformation.html) |  | [optional] |
| **NewestVersion** | [**EdgeVersionInformation**](EdgeVersionInformation.html) |  | [optional] |
{: class="table table-striped"}


