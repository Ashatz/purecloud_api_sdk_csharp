---
title: AggregationResultEntry
---
## ININ.PureCloudApi.Model.AggregationResultEntry

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Count** | **long?** |  | [optional] |
| **Value** | **string** | For termFrequency aggregations | [optional] |
| **Gte** | **double?** | For numericRange aggregations | [optional] |
| **Lt** | **double?** | For numericRange aggregations | [optional] |
{: class="table table-striped"}


