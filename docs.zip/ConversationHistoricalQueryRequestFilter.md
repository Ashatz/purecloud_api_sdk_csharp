---
title: ConversationHistoricalQueryRequestFilter
---
## .ConversationHistoricalQueryRequestFilter

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Target** | **string** |  | [optional] |
| **_Operator** | **string** |  | [optional] |
| **Values** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


