---
title: ConsultTransferResponse
---
## ININ.PureCloudApi.Model.ConsultTransferResponse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **DestinationParticipantId** | **string** | Participant ID to whom the call is being transferred. | |
{: class="table table-striped"}


