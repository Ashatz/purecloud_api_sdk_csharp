---
title: ImportStatus
---
## ININ.PureCloudApi.Model.ImportStatus

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **State** | **string** |  | [optional] |
| **TotalRecords** | **long?** |  | [optional] |
| **CompletedRecords** | **long?** |  | [optional] |
| **PercentComplete** | **int?** |  | [optional] |
| **FailureReason** | **string** |  | [optional] |
{: class="table table-striped"}


