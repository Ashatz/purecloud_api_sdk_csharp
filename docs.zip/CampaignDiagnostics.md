---
title: CampaignDiagnostics
---
## ININ.PureCloudApi.Model.CampaignDiagnostics

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **CallableContacts** | [**CallableContactsDiagnostic**](CallableContactsDiagnostic.html) |  | [optional] |
| **QueueUtilizationDiagnostic** | [**QueueUtilizationDiagnostic**](QueueUtilizationDiagnostic.html) |  | [optional] |
| **OutstandingInteractionsCount** | **int?** |  | [optional] |
{: class="table table-striped"}


