---
title: NumericRange
---
## ININ.PureCloudApi.Model.NumericRange

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Gt** | **double?** | Greater than | [optional] |
| **Gte** | **double?** | Greater than or equal to | [optional] |
| **Lt** | **double?** | Less than | [optional] |
| **Lte** | **double?** | Less than or equal to | [optional] |
{: class="table table-striped"}


