---
title: Bullseye
---
## ININ.PureCloudApi.Model.Bullseye

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Rings** | [**List&lt;Ring&gt;**](Ring.html) |  | [optional] |
{: class="table table-striped"}


