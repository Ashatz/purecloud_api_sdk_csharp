---
title: ClientTextTableTransform
---
## ININ.PureCloudApi.Model.ClientTextTableTransform

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **EndpointId** | **string** |  | [optional] |
| **FilenameReplaces** | [**List&lt;BasicTransform&gt;**](BasicTransform.html) |  | [optional] |
| **Tags** | [**List&lt;TagModel&gt;**](TagModel.html) |  | [optional] |
| **Name** | **string** |  | [optional] |
| **Comments** | **string** |  | [optional] |
| **Delimiter** | **string** |  | [optional] |
| **Table** | [**TableTransform**](TableTransform.html) |  | [optional] |
{: class="table table-striped"}


