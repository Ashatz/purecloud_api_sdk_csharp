---
title: FlowBodyFormat
---
## ININ.PureCloudApi.Model.FlowBodyFormat

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **SchemaUri** | **string** |  | [optional] |
| **Description** | **string** |  | [optional] |
{: class="table table-striped"}


