---
title: CallableContactsDiagnostic
---
## ININ.PureCloudApi.Model.CallableContactsDiagnostic

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **DncLists** | [**List&lt;UriReference&gt;**](UriReference.html) |  | [optional] |
| **CallableTimeSet** | [**UriReference**](UriReference.html) |  | [optional] |
| **RuleSets** | [**List&lt;UriReference&gt;**](UriReference.html) |  | [optional] |
{: class="table table-striped"}


