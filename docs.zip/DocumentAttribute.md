---
title: DocumentAttribute
---
## ININ.PureCloudApi.Model.DocumentAttribute

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Attribute** | [**ININ.PureCloudApi.Model.Attribute**](Attribute.html) |  | [optional] |
| **Values** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


