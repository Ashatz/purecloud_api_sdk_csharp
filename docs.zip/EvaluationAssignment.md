---
title: EvaluationAssignment
---
## ININ.PureCloudApi.Model.EvaluationAssignment

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **EvaluationForm** | [**EvaluationForm**](EvaluationForm.html) |  | [optional] |
| **User** | [**User**](User.html) |  | [optional] |
{: class="table table-striped"}


