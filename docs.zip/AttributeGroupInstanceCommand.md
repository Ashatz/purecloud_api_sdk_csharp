---
title: AttributeGroupInstanceCommand
---
## .AttributeGroupInstanceCommand

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Instance** | [**AttributeGroupInstance**](AttributeGroupInstance.html) |  | [optional] |
| **Status** | [**CommandStatus**](CommandStatus.html) |  | [optional] |
| **Created** | **bool?** |  | [optional] [default to false]|
{: class="table table-striped"}


