---
title: ArchiveRetention
---
## ININ.PureCloudApi.Model.ArchiveRetention

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Days** | **int?** |  | [optional] |
| **StorageMedium** | **string** |  | [optional] |
{: class="table table-striped"}


