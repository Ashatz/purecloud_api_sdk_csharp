---
title: DomainNetworkRoute
---
## ININ.PureCloudApi.Model.DomainNetworkRoute

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Prefix** | **string** |  | [optional] |
| **Nexthop** | **string** |  | [optional] |
| **Persistent** | **bool?** |  | [optional] [default to false]|
| **Metric** | **int?** |  | [optional] |
| **Family** | **int?** |  | [optional] |
{: class="table table-striped"}


