---
title: EmailAttachment
---
## ININ.PureCloudApi.Model.EmailAttachment

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
| **ContentPath** | **string** |  | [optional] |
| **ContentType** | **string** |  | [optional] |
| **AttachmentId** | **string** |  | [optional] |
| **ContentLength** | **int?** |  | [optional] |
{: class="table table-striped"}


