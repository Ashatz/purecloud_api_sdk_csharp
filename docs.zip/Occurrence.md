---
title: Occurrence
---
## .Occurrence

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Limit** | **int?** |  | [optional] |
| **Type** | **string** |  | [optional] |
{: class="table table-striped"}


