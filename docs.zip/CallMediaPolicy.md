---
title: CallMediaPolicy
---
## ININ.PureCloudApi.Model.CallMediaPolicy

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Actions** | [**PolicyActions**](PolicyActions.html) | Actions applied when specified conditions are met | [optional] |
| **Conditions** | [**CallMediaPolicyConditions**](CallMediaPolicyConditions.html) | Conditions for when actions should be applied | [optional] |
{: class="table table-striped"}


