---
title: Dns
---
## ININ.PureCloudApi.Model.Dns

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **Ip** | **string** |  | [optional] |
| **Port** | **int?** |  | [optional] |
{: class="table table-striped"}


