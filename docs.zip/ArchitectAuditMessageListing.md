---
title: ArchitectAuditMessageListing
---
## ININ.PureCloudApi.Model.ArchitectAuditMessageListing

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **PageSize** | **int?** |  | [optional] |
| **PageNumber** | **int?** |  | [optional] |
| **Total** | **long?** |  | [optional] |
| **Entities** | [**List&lt;ArchitectAuditMessage&gt;**](ArchitectAuditMessage.html) |  | [optional] |
| **PageCount** | **int?** |  | [optional] |
{: class="table table-striped"}


