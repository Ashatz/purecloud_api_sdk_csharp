---
title: GroupsSearchResponse
---
## ININ.PureCloudApi.Model.GroupsSearchResponse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Total** | **long?** |  | [optional] |
| **PageCount** | **int?** |  | [optional] |
| **PageSize** | **int?** |  | [optional] |
| **PageNumber** | **int?** |  | [optional] |
| **PreviousPage** | **string** |  | [optional] |
| **CurrentPage** | **string** |  | [optional] |
| **NextPage** | **string** |  | [optional] |
| **Types** | **List&lt;string&gt;** |  | [optional] |
| **Results** | [**List&lt;Group&gt;**](Group.html) |  | [optional] |
{: class="table table-striped"}


