---
title: CallRecord
---
## ININ.PureCloudApi.Model.CallRecord

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **LastAttempt** | **DateTime?** | Date time is represented as an ISO-8601 string. For example: yyyy-MM-ddTHH:mm:ss.SSSZ | [optional] |
| **LastResult** | **string** |  | [optional] |
{: class="table table-striped"}


