---
title: ContactSort
---
## ININ.PureCloudApi.Model.ContactSort

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **FieldName** | **string** |  | [optional] |
| **Direction** | **string** |  | [optional] |
{: class="table table-striped"}


