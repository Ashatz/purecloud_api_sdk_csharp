---
title: OrganizationProductEntityListing
---
## ININ.PureCloudApi.Model.OrganizationProductEntityListing

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **PageSize** | **int?** |  | [optional] |
| **PageNumber** | **int?** |  | [optional] |
| **Total** | **long?** |  | [optional] |
| **Entities** | [**List&lt;DomainOrganizationProduct&gt;**](DomainOrganizationProduct.html) |  | [optional] |
| **PageCount** | **int?** |  | [optional] |
{: class="table table-striped"}


