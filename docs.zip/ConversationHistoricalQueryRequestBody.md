---
title: ConversationHistoricalQueryRequestBody
---
## .ConversationHistoricalQueryRequestBody

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **PageSize** | **int?** |  | [optional] |
| **Maximum** | **int?** |  | [optional] |
| **Filters** | [**List&lt;ConversationHistoricalQueryRequestFilter&gt;**](ConversationHistoricalQueryRequestFilter.html) |  | [optional] |
| **Facets** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


