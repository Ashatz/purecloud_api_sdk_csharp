---
title: FailedObject
---
## ININ.PureCloudApi.Model.FailedObject

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **Version** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **ErrorCode** | **string** |  | [optional] |
{: class="table table-striped"}


