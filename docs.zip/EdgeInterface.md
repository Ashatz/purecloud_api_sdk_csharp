---
title: EdgeInterface
---
## ININ.PureCloudApi.Model.EdgeInterface

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Type** | **string** |  | [optional] |
| **IpAddress** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **MacAddress** | **string** |  | [optional] |
| **IfName** | **string** |  | [optional] |
| **Endpoints** | [**List&lt;UriReference&gt;**](UriReference.html) |  | [optional] |
| **LineTypes** | **List&lt;string&gt;** |  | [optional] |
| **AddressFamilyId** | **string** |  | [optional] |
{: class="table table-striped"}


