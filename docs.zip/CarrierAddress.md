---
title: CarrierAddress
---
## ININ.PureCloudApi.Model.CarrierAddress

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **StreetAddress1** | **string** |  | [optional] |
| **StreetAddress2** | **string** |  | [optional] |
| **City** | **string** |  | [optional] |
| **State** | **string** |  | [optional] |
| **Zipcode** | **string** |  | [optional] |
{: class="table table-striped"}


