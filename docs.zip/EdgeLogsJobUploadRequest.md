---
title: EdgeLogsJobUploadRequest
---
## ININ.PureCloudApi.Model.EdgeLogsJobUploadRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **FileIds** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


