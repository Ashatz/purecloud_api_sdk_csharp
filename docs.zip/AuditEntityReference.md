---
title: AuditEntityReference
---
## ININ.PureCloudApi.Model.AuditEntityReference

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **SelfUri** | **string** |  | [optional] |
| **Type** | **string** |  | [optional] |
| **Action** | **string** |  | [optional] |
{: class="table table-striped"}


