---
title: OrganizationAddress
---
## .OrganizationAddress

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Display** | **string** |  | [optional] |
| **Address** | **string** |  | [optional] |
| **Type** | **string** |  | [optional] |
| **MediaType** | **string** |  | [optional] |
{: class="table table-striped"}


