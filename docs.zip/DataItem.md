---
title: DataItem
---
## ININ.PureCloudApi.Model.DataItem

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **DataItemId** | **string** |  | [optional] |
| **Value** | **string** |  | [optional] |
| **Type** | **string** |  | [optional] |
{: class="table table-striped"}


