---
title: ObservationDataContainer
---
## ININ.PureCloudApi.Model.ObservationDataContainer

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Group** | **Dictionary&lt;string, string&gt;** | A mapping from dimension to value | [optional] |
| **Data** | [**List&lt;AggregateMetricData&gt;**](AggregateMetricData.html) |  | [optional] |
{: class="table table-striped"}


