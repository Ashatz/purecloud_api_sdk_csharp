---
title: AvailableTopic
---
## ININ.PureCloudApi.Model.AvailableTopic

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **Description** | **string** |  | [optional] |
| **Schema** | **Dictionary&lt;string, Object&gt;** |  | [optional] |
{: class="table table-striped"}


