---
title: App
---
## ININ.PureCloudApi.Model.App

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **AppId** | **string** |  | [optional] |
| **AppVersion** | **string** |  | [optional] |
{: class="table table-striped"}


