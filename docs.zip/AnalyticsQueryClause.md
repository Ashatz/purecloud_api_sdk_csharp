---
title: AnalyticsQueryClause
---
## ININ.PureCloudApi.Model.AnalyticsQueryClause

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Type** | **string** |  | [optional] |
| **Predicates** | [**List&lt;AnalyticsQueryPredicate&gt;**](AnalyticsQueryPredicate.html) | Like a three-word sentence: (attribute-name) (operator) (target-value). These can be one of three types: dimension, property, metric. | [optional] |
{: class="table table-striped"}


