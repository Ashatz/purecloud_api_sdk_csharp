---
title: ContentSortItem
---
## ININ.PureCloudApi.Model.ContentSortItem

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
| **Ascending** | **bool?** |  | [optional] [default to false]|
{: class="table table-striped"}


