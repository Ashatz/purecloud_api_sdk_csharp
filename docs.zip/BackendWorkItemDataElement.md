---
title: BackendWorkItemDataElement
---
## .BackendWorkItemDataElement

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **Prompt** | **string** |  | [optional] |
| **DataItemId** | **string** |  | [optional] |
| **ControlType** | **string** |  | [optional] |
{: class="table table-striped"}


