---
title: FlowTerminateRequest
---
## ININ.PureCloudApi.Model.FlowTerminateRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Reason** | **string** | Reason code for a termination. | [optional] |
{: class="table table-striped"}


