---
title: DialerPlaceCallCommand
---
## .DialerPlaceCallCommand

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **CallId** | **string** |  | [optional] |
| **PhoneNumber** | **string** |  | [optional] |
{: class="table table-striped"}


