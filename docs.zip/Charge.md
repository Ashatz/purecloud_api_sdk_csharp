---
title: Charge
---
## ININ.PureCloudApi.Model.Charge

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **LicenseCount** | **int?** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **Description** | **string** |  | [optional] |
| **Price** | **double?** |  | [optional] |
| **UnitOfMeasure** | **string** |  | [optional] |
| **BillingPeriod** | **string** |  | [optional] |
| **Quantity** | **int?** |  | [optional] |
| **IncludedUnits** | **int?** |  | [optional] |
{: class="table table-striped"}


