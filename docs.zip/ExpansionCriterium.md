---
title: ExpansionCriterium
---
## ININ.PureCloudApi.Model.ExpansionCriterium

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Type** | **string** |  | [optional] |
| **Threshold** | **double?** |  | [optional] |
{: class="table table-striped"}


