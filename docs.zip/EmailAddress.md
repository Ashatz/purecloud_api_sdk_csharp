---
title: EmailAddress
---
## ININ.PureCloudApi.Model.EmailAddress

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Email** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
{: class="table table-striped"}


