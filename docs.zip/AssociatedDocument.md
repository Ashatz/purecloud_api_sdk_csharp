---
title: AssociatedDocument
---
## ININ.PureCloudApi.Model.AssociatedDocument

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Document** | [**Document**](Document.html) | the document associated with the workitem | |
| **DocumentAssociationType** | **string** | the document association type | [optional] |
{: class="table table-striped"}


