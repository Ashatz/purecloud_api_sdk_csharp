---
title: BatchCommand
---
## ININ.PureCloudApi.Model.BatchCommand

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Items** | [**List&lt;BatchItem&gt;**](BatchItem.html) |  | [optional] |
| **CommandId** | **string** |  | [optional] |
{: class="table table-striped"}


