---
title: AuditUser
---
## ININ.PureCloudApi.Model.AuditUser

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **Display** | **string** |  | [optional] |
{: class="table table-striped"}


