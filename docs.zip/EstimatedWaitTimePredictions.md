---
title: EstimatedWaitTimePredictions
---
## ININ.PureCloudApi.Model.EstimatedWaitTimePredictions

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Results** | [**List&lt;PredictionResults&gt;**](PredictionResults.html) | Returned upon a successful estimated wait time request. | |
{: class="table table-striped"}


