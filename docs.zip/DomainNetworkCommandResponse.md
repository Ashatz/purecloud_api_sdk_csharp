---
title: DomainNetworkCommandResponse
---
## ININ.PureCloudApi.Model.DomainNetworkCommandResponse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **CorrelationId** | **string** |  | [optional] |
| **CommandName** | **string** |  | [optional] |
| **Acknowledged** | **bool?** |  | [optional] [default to false]|
| **ErrorInfo** | [**ErrorDetails**](ErrorDetails.html) |  | [optional] |
{: class="table table-striped"}


