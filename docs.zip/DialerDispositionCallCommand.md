---
title: DialerDispositionCallCommand
---
## .DialerDispositionCallCommand

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **CallId** | **string** |  | [optional] |
| **WrapupCodeId** | **string** |  | [optional] |
| **Contact** | [**Contact**](Contact.html) |  | [optional] |
{: class="table table-striped"}


