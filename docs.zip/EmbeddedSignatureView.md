---
title: EmbeddedSignatureView
---
## ININ.PureCloudApi.Model.EmbeddedSignatureView

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **View** | [**View**](View.html) |  | [optional] |
{: class="table table-striped"}


