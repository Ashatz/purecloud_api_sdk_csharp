---
title: Address
---
## ININ.PureCloudApi.Model.Address

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Country** | **string** |  | [optional] |
| **A1** | **string** |  | [optional] |
| **A3** | **string** |  | [optional] |
| **RD** | **string** |  | [optional] |
| **HNO** | **string** |  | [optional] |
| **LOC** | **string** |  | [optional] |
| **NAM** | **string** |  | [optional] |
| **PC** | **string** |  | [optional] |
{: class="table table-striped"}


