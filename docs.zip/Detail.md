---
title: Detail
---
## ININ.PureCloudApi.Model.Detail

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ErrorCode** | **string** |  | [optional] |
| **FieldName** | **string** |  | [optional] |
| **EntityId** | **string** |  | [optional] |
| **EntityName** | **string** |  | [optional] |
{: class="table table-striped"}


