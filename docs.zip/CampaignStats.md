---
title: CampaignStats
---
## ININ.PureCloudApi.Model.CampaignStats

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ContactRate** | [**ConnectRate**](ConnectRate.html) |  | [optional] |
| **IdleAgents** | **int?** |  | [optional] |
| **AdjustedCallsPerAgent** | **double?** |  | [optional] |
| **OutstandingCalls** | **int?** |  | [optional] |
{: class="table table-striped"}


