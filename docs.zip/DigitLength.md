---
title: DigitLength
---
## ININ.PureCloudApi.Model.DigitLength

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Start** | **string** |  | [optional] |
| **End** | **string** |  | [optional] |
{: class="table table-striped"}


