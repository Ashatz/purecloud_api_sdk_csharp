---
title: AttributeFilterItem
---
## ININ.PureCloudApi.Model.AttributeFilterItem

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **_Operator** | **string** |  | [optional] |
| **Values** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


