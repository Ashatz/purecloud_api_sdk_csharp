---
title: ControlOptions
---
## ININ.PureCloudApi.Model.ControlOptions

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Value** | **string** |  | [optional] |
| **Label** | **string** |  | [optional] |
{: class="table table-striped"}


