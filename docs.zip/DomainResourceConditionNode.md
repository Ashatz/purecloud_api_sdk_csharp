---
title: DomainResourceConditionNode
---
## ININ.PureCloudApi.Model.DomainResourceConditionNode

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **VariableName** | **string** |  | [optional] |
| **_Operator** | **string** |  | [optional] |
| **Operands** | [**List&lt;DomainResourceConditionValue&gt;**](DomainResourceConditionValue.html) |  | [optional] |
| **Conjunction** | **string** |  | [optional] |
| **Terms** | [**List&lt;DomainResourceConditionNode&gt;**](DomainResourceConditionNode.html) |  | [optional] |
{: class="table table-striped"}


