---
title: GreetingAudioFile
---
## ININ.PureCloudApi.Model.GreetingAudioFile

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **DurationMilliseconds** | **long?** |  | [optional] |
| **SizeBytes** | **long?** |  | [optional] |
| **SelfUri** | **string** |  | [optional] |
{: class="table table-striped"}


