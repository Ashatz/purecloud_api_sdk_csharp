---
title: AnalyticsConversationQueryResponse
---
## ININ.PureCloudApi.Model.AnalyticsConversationQueryResponse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Conversations** | [**List&lt;AnalyticsConversation&gt;**](AnalyticsConversation.html) |  | [optional] |
| **Aggregations** | [**List&lt;AggregationResult&gt;**](AggregationResult.html) |  | [optional] |
{: class="table table-striped"}


