---
title: ManagementUnit
---
## ININ.PureCloudApi.Model.ManagementUnit

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **Name** | **string** |  | [optional] |
| **StartDayOfWeek** | **string** |  | [optional] |
| **Timezone** | **string** |  | [optional] |
| **Version** | **int?** |  | [optional] |
| **SelfUri** | **string** | The URI for this object | [optional] |
{: class="table table-striped"}


