---
title: Destination
---
## ININ.PureCloudApi.Model.Destination

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Address** | **string** | Address or phone number. | |
| **Name** | **string** |  | [optional] |
| **UserId** | **string** |  | [optional] |
| **QueueId** | **string** |  | [optional] |
{: class="table table-striped"}


