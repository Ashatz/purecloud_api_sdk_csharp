---
title: MediaResult
---
## ININ.PureCloudApi.Model.MediaResult

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **MediaUri** | **string** |  | [optional] |
| **WaveformData** | **List&lt;float?&gt;** |  | [optional] |
{: class="table table-striped"}


