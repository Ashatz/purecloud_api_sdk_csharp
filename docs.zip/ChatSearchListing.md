---
title: ChatSearchListing
---
## .ChatSearchListing

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **PageSize** | **int?** |  | [optional] |
| **PageNumber** | **int?** |  | [optional] |
| **Total** | **long?** |  | [optional] |
| **Entities** | [**List&lt;ChatSearchItem&gt;**](ChatSearchItem.html) |  | [optional] |
| **SelfUri** | **string** |  | [optional] |
| **PreviousUri** | **string** |  | [optional] |
| **NextUri** | **string** |  | [optional] |
| **FirstUri** | **string** |  | [optional] |
| **LastUri** | **string** |  | [optional] |
| **PageCount** | **int?** |  | [optional] |
{: class="table table-striped"}


