---
title: AuditSearchResult
---
## ININ.PureCloudApi.Model.AuditSearchResult

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **PageNumber** | **int?** |  | [optional] |
| **PageSize** | **int?** |  | [optional] |
| **Total** | **int?** |  | [optional] |
| **PageCount** | **int?** |  | [optional] |
| **FacetInfo** | [**List&lt;FacetInfo&gt;**](FacetInfo.html) |  | [optional] |
| **AuditMessages** | [**List&lt;AuditMessage&gt;**](AuditMessage.html) |  | [optional] |
{: class="table table-striped"}


