---
title: FacetKeyAttribute
---
## ININ.PureCloudApi.Model.FacetKeyAttribute

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **Count** | **int?** |  | [optional] |
{: class="table table-striped"}


