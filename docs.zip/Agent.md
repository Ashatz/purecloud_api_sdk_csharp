---
title: Agent
---
## ININ.PureCloudApi.Model.Agent

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Stage** | **string** |  | [optional] |
{: class="table table-striped"}


