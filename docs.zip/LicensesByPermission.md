---
title: LicensesByPermission
---
## ININ.PureCloudApi.Model.LicensesByPermission

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **Name** | **string** |  | [optional] |
| **Licenses** | [**List&lt;License&gt;**](License.html) |  | [optional] |
{: class="table table-striped"}


