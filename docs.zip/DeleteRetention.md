---
title: DeleteRetention
---
## ININ.PureCloudApi.Model.DeleteRetention

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Days** | **int?** |  | [optional] |
{: class="table table-striped"}


