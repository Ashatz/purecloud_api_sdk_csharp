---
title: AggregationRange
---
## ININ.PureCloudApi.Model.AggregationRange

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Gte** | **double?** | Greater than or equal to | [optional] |
| **Lt** | **double?** | Less than | [optional] |
{: class="table table-striped"}


