---
title: ConsultTransferUpdate
---
## ININ.PureCloudApi.Model.ConsultTransferUpdate

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **SpeakTo** | **string** | Determines to whom the initiating participant is speaking. | |
{: class="table table-striped"}


