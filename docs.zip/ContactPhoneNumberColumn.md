---
title: ContactPhoneNumberColumn
---
## ININ.PureCloudApi.Model.ContactPhoneNumberColumn

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ColumnName** | **string** |  | [optional] |
| **Type** | **string** |  | [optional] |
| **CallableTimeColumn** | **string** |  | [optional] |
{: class="table table-striped"}


