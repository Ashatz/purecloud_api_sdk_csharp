---
title: NocSupport
---
## ININ.PureCloudApi.Model.NocSupport

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Phone** | **string** |  | [optional] |
| **Email** | **string** |  | [optional] |
{: class="table table-striped"}


