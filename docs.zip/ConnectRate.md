---
title: ConnectRate
---
## ININ.PureCloudApi.Model.ConnectRate

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Attempts** | **long?** |  | [optional] |
| **Connects** | **long?** |  | [optional] |
| **ConnectRatio** | **double?** |  | [optional] |
{: class="table table-striped"}


