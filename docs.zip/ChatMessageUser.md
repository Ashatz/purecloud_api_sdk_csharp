---
title: ChatMessageUser
---
## ININ.PureCloudApi.Model.ChatMessageUser

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **DisplayName** | **string** |  | [optional] |
| **Username** | **string** |  | [optional] |
| **Images** | [**List&lt;UserImage&gt;**](UserImage.html) |  | [optional] |
{: class="table table-striped"}


