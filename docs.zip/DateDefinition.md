---
title: DateDefinition
---
## .DateDefinition

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Type** | **string** |  | [optional] |
{: class="table table-striped"}


