---
title: CampaignScheduleIntervals
---
## ININ.PureCloudApi.Model.CampaignScheduleIntervals

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Start** | **DateTime?** | Date time is represented as an ISO-8601 string. For example: yyyy-MM-ddTHH:mm:ss.SSSZ | [optional] |
| **End** | **DateTime?** | Date time is represented as an ISO-8601 string. For example: yyyy-MM-ddTHH:mm:ss.SSSZ | [optional] |
{: class="table table-striped"}


