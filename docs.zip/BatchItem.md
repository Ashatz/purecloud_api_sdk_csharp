---
title: BatchItem
---
## ININ.PureCloudApi.Model.BatchItem

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Method** | **string** |  | [optional] |
| **Url** | **string** |  | [optional] |
| **Body** | [**BatchItemBody**](BatchItemBody.html) |  | [optional] |
{: class="table table-striped"}


