---
title: DomainRole
---
## ININ.PureCloudApi.Model.DomainRole

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The ID of the role | [optional] |
| **Name** | **string** | The name of the role | [optional] |
{: class="table table-striped"}


