---
title: ClientTransformModel
---
## .ClientTransformModel

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **EndpointId** | **string** |  | [optional] |
| **FilenameReplaces** | [**List&lt;BasicTransform&gt;**](BasicTransform.html) |  | [optional] |
| **Tags** | [**List&lt;TagModel&gt;**](TagModel.html) |  | [optional] |
| **Name** | **string** |  | [optional] |
{: class="table table-striped"}


