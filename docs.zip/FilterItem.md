---
title: FilterItem
---
## ININ.PureCloudApi.Model.FilterItem

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
| **Type** | **string** |  | [optional] |
| **_Operator** | **string** |  | [optional] |
| **Values** | **List&lt;string&gt;** |  | [optional] |
| **Filters** | [**List&lt;FilterItem&gt;**](FilterItem.html) |  | [optional] |
{: class="table table-striped"}


