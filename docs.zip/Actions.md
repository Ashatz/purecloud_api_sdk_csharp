---
title: Actions
---
## ININ.PureCloudApi.Model.Actions

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **SkillsToRemove** | [**List&lt;SkillsToRemove&gt;**](SkillsToRemove.html) |  | [optional] |
{: class="table table-striped"}


