---
title: Chat
---
## ININ.PureCloudApi.Model.Chat

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **JabberId** | **string** |  | [optional] |
{: class="table table-striped"}


