---
title: CreateCallbackCommand
---
## ININ.PureCloudApi.Model.CreateCallbackCommand

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ScriptId** | **string** |  | [optional] |
| **QueueId** | **string** |  | [optional] |
| **CallbackUserName** | **string** |  | [optional] |
| **CallbackNumbers** | **List&lt;string&gt;** |  | [optional] |
| **CountryCode** | **string** |  | [optional] |
| **SkipEnabled** | **bool?** |  | [optional] [default to false]|
{: class="table table-striped"}


