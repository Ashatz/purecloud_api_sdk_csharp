---
title: IndexedTransform
---
## ININ.PureCloudApi.Model.IndexedTransform

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Replaces** | [**List&lt;TransformLens&gt;**](TransformLens.html) |  | [optional] |
| **EntityPath** | **List&lt;string&gt;** |  | [optional] |
| **Index** | **int?** |  | [optional] |
| **Name** | **string** |  | [optional] |
{: class="table table-striped"}


