---
title: FacetItem
---
## .FacetItem

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
| **FilterValue** | **string** |  | [optional] |
| **Count** | **int?** |  | [optional] |
{: class="table table-striped"}


