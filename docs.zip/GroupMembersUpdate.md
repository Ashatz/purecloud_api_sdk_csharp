---
title: GroupMembersUpdate
---
## ININ.PureCloudApi.Model.GroupMembersUpdate

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **MemberIds** | **List&lt;string&gt;** |  | [optional] |
| **Version** | **int?** |  | [optional] |
{: class="table table-striped"}


