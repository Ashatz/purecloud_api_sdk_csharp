---
title: DownloadResponse
---
## ININ.PureCloudApi.Model.DownloadResponse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ContentLocationUri** | **string** |  | [optional] |
| **ImageUri** | **string** |  | [optional] |
{: class="table table-striped"}


