---
title: DocumentThumbnail
---
## ININ.PureCloudApi.Model.DocumentThumbnail

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Resolution** | **string** |  | [optional] |
| **ImageUri** | **string** |  | [optional] |
{: class="table table-striped"}


