---
title: BasicTransform
---
## ININ.PureCloudApi.Model.BasicTransform

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Replaces** | [**List&lt;TransformLens&gt;**](TransformLens.html) |  | [optional] |
| **EntityPath** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


