---
title: FacetTerm
---
## ININ.PureCloudApi.Model.FacetTerm

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Term** | **string** |  | [optional] |
| **Key** | **long?** |  | [optional] |
| **Id** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **Count** | **long?** |  | [optional] |
| **Time** | **DateTime?** | Date time is represented as an ISO-8601 string. For example: yyyy-MM-ddTHH:mm:ss.SSSZ | [optional] |
{: class="table table-striped"}


