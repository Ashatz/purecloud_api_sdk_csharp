---
title: DomainNetworkAddress
---
## ININ.PureCloudApi.Model.DomainNetworkAddress

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Type** | **string** |  | [optional] |
| **Address** | **string** |  | [optional] |
| **Persistent** | **bool?** |  | [optional] [default to false]|
| **Family** | **int?** |  | [optional] |
{: class="table table-striped"}


