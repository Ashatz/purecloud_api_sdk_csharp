---
title: DomainPermission
---
## ININ.PureCloudApi.Model.DomainPermission

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Domain** | **string** |  | [optional] |
| **EntityType** | **string** |  | [optional] |
| **Action** | **string** |  | [optional] |
| **Label** | **string** |  | [optional] |
| **AllowsConditions** | **bool?** |  | [optional] [default to false]|
{: class="table table-striped"}


