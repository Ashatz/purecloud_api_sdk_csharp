---
title: AttributeRestrictions
---
## .AttributeRestrictions

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Date** | [**DateDefinition**](DateDefinition.html) |  | [optional] |
| **Number** | [**NumberDefinition**](NumberDefinition.html) |  | [optional] |
| **_String** | [**StringDefinition**](StringDefinition.html) |  | [optional] |
| **List** | [**ListDefinition**](ListDefinition.html) |  | [optional] |
{: class="table table-striped"}


