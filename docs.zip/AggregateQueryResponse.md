---
title: AggregateQueryResponse
---
## ININ.PureCloudApi.Model.AggregateQueryResponse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Results** | [**List&lt;AggregateDataContainer&gt;**](AggregateDataContainer.html) |  | [optional] |
{: class="table table-striped"}


