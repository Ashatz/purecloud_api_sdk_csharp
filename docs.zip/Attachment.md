---
title: Attachment
---
## ININ.PureCloudApi.Model.Attachment

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **AttachmentId** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **ContentUri** | **string** |  | [optional] |
| **ContentType** | **string** |  | [optional] |
| **ContentLength** | **int?** |  | [optional] |
{: class="table table-striped"}


