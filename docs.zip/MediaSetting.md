---
title: MediaSetting
---
## ININ.PureCloudApi.Model.MediaSetting

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **AlertingTimeoutSeconds** | **int?** |  | [optional] |
| **ServiceLevel** | [**ServiceLevel**](ServiceLevel.html) |  | [optional] |
{: class="table table-striped"}


