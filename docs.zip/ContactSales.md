---
title: ContactSales
---
## ININ.PureCloudApi.Model.ContactSales

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **Name** | **string** |  | [optional] |
| **Email** | **string** |  | [optional] |
| **FirstName** | **string** |  | [optional] |
| **LastName** | **string** |  | [optional] |
| **ContactPhone** | **string** |  | [optional] |
| **Country** | **string** |  | [optional] |
| **Title** | **string** |  | [optional] |
| **Message** | **string** |  | [optional] |
| **Language** | **string** |  | [optional] |
| **ProductName** | **string** |  | [optional] |
| **QuoteId** | **string** |  | [optional] |
| **SelfUri** | **string** | The URI for this object | [optional] |
{: class="table table-striped"}


