---
title: BatchItemBody
---
## ININ.PureCloudApi.Model.BatchItemBody

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
{: class="table table-striped"}


