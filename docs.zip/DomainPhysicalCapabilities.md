---
title: DomainPhysicalCapabilities
---
## ININ.PureCloudApi.Model.DomainPhysicalCapabilities

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Vlan** | **bool?** |  | [optional] [default to false]|
| **Team** | **bool?** |  | [optional] [default to false]|
{: class="table table-striped"}


