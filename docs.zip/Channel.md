---
title: Channel
---
## ININ.PureCloudApi.Model.Channel

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **ConnectUri** | **string** |  | [optional] |
{: class="table table-striped"}


