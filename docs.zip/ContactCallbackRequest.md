---
title: ContactCallbackRequest
---
## ININ.PureCloudApi.Model.ContactCallbackRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **CampaignId** | **string** |  | [optional] |
| **ContactListId** | **string** |  | [optional] |
| **ContactId** | **string** |  | [optional] |
| **PhoneColumn** | **string** |  | [optional] |
| **Schedule** | **string** |  | [optional] |
{: class="table table-striped"}


