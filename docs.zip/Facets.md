---
title: Facets
---
## .Facets

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Count** | **int?** |  | [optional] |
| **FacetGroups** | [**List&lt;FacetGroup&gt;**](FacetGroup.html) |  | [optional] |
{: class="table table-striped"}


