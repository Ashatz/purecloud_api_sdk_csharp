---
title: ListDefinition
---
## .ListDefinition

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Values** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


