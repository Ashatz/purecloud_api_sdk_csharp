---
title: Action
---
## .Action

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Type** | **string** |  | [optional] |
| **ActionTypeName** | **string** |  | [optional] |
| **UpdateOption** | **string** |  | [optional] |
| **Properties** | **Dictionary&lt;string, string&gt;** |  | [optional] |
{: class="table table-striped"}


