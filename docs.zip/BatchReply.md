---
title: BatchReply
---
## ININ.PureCloudApi.Model.BatchReply

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Items** | [**List&lt;BatchReplyItem&gt;**](BatchReplyItem.html) |  | [optional] |
{: class="table table-striped"}


