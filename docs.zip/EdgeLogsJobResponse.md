---
title: EdgeLogsJobResponse
---
## ININ.PureCloudApi.Model.EdgeLogsJobResponse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The created job id. | [optional] |
| **Name** | **string** |  | [optional] |
| **SelfUri** | **string** | The URI for this object | [optional] |
{: class="table table-striped"}


