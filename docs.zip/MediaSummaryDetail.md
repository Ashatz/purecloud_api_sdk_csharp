---
title: MediaSummaryDetail
---
## ININ.PureCloudApi.Model.MediaSummaryDetail

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Active** | **int?** |  | [optional] |
| **Acw** | **int?** |  | [optional] |
{: class="table table-striped"}


