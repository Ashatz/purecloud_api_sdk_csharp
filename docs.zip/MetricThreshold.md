---
title: MetricThreshold
---
## .MetricThreshold

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Op** | **string** |  | [optional] |
| **Value** | **double?** |  | [optional] |
{: class="table table-striped"}


