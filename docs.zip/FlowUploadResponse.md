---
title: FlowUploadResponse
---
## ININ.PureCloudApi.Model.FlowUploadResponse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Uri** | **string** | uri destination to upload file to | [optional] |
| **UploadToken** | **string** | token to send along when creating versioned flow so the file can be bound to the metadata | [optional] |
{: class="table table-striped"}


