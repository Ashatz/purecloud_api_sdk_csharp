---
title: CallCommand
---
## ININ.PureCloudApi.Model.CallCommand

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **CallNumber** | **string** |  | [optional] |
{: class="table table-striped"}


