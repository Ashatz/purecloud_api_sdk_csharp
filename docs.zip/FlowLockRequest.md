---
title: FlowLockRequest
---
## .FlowLockRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Locked** | **bool?** | Change the locked state of the flow definition.  True to attempt to lock for modification, false to release the lock. | [default to false]|
{: class="table table-striped"}


