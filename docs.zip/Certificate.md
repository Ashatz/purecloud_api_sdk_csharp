---
title: Certificate
---
## ININ.PureCloudApi.Model.Certificate

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **_Certificate** | **string** | The certificate to parse. | |
{: class="table table-striped"}


