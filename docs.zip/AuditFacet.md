---
title: AuditFacet
---
## ININ.PureCloudApi.Model.AuditFacet

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
| **Type** | **string** |  | [optional] |
{: class="table table-striped"}


