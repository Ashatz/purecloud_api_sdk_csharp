---
title: BillingAddress
---
## ININ.PureCloudApi.Model.BillingAddress

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **Name** | **string** |  | [optional] |
| **Street** | **string** |  | [optional] |
| **City** | **string** |  | [optional] |
| **CountryName** | **string** |  | [optional] |
| **StateName** | **string** |  | [optional] |
| **PostalCode** | **string** |  | [optional] |
| **SelfUri** | **string** | The URI for this object | [optional] |
{: class="table table-striped"}


