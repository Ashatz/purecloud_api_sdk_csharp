---
title: InstanceMemberFilter
---
## .InstanceMemberFilter

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **Values** | **List&lt;string&gt;** |  | [optional] |
| **Type** | **string** |  | [optional] |
{: class="table table-striped"}


