---
title: AuditFilter
---
## ININ.PureCloudApi.Model.AuditFilter

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
| **Type** | **string** |  | [optional] |
| **_Operator** | **string** |  | [optional] |
| **Values** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


