---
title: GroupImages
---
## .GroupImages

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ActiveImages** | [**List&lt;UserImage&gt;**](UserImage.html) |  | [optional] |
{: class="table table-striped"}


