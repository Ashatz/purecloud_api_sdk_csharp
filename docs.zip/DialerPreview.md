---
title: DialerPreview
---
## ININ.PureCloudApi.Model.DialerPreview

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **ContactId** | **string** |  | [optional] |
| **ContactListId** | **string** |  | [optional] |
| **CampaignId** | **string** |  | [optional] |
| **PhoneNumberColumns** | [**List&lt;PhoneNumberColumn&gt;**](PhoneNumberColumn.html) |  | [optional] |
{: class="table table-striped"}


