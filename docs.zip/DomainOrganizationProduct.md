---
title: DomainOrganizationProduct
---
## ININ.PureCloudApi.Model.DomainOrganizationProduct

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
{: class="table table-striped"}


