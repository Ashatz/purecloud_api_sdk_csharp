---
title: MediaPolicy
---
## ININ.PureCloudApi.Model.MediaPolicy

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Conditions** | [**PolicyConditions**](PolicyConditions.html) | Conditions for when actions should be applied | [optional] |
| **Actions** | [**PolicyActions**](PolicyActions.html) | Actions applied when specified conditions are met | [optional] |
{: class="table table-striped"}


