---
title: LocationEmergencyNumber
---
## ININ.PureCloudApi.Model.LocationEmergencyNumber

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **E164** | **string** |  | [optional] |
| **Number** | **string** |  | [optional] |
| **Type** | **string** | The type of emergency number. | [optional] |
{: class="table table-striped"}


