---
title: Discount
---
## ININ.PureCloudApi.Model.Discount

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **Name** | **string** |  | [optional] |
| **AnnualPrePay** | **bool?** |  | [optional] [default to false]|
| **_Discount** | **string** |  | [optional] |
| **Maximum** | **string** |  | [optional] |
| **Minimum** | **string** |  | [optional] |
| **ProductCategory** | **string** |  | [optional] |
| **SelfUri** | **string** | The URI for this object | [optional] |
{: class="table table-striped"}


