---
title: DeltaResponse
---
## ININ.PureCloudApi.Model.DeltaResponse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ContextToken** | **string** |  | [optional] |
| **Documents** | [**List&lt;DeltaDocument&gt;**](DeltaDocument.html) |  | [optional] |
| **HasMore** | **bool?** |  | [optional] [default to false]|
{: class="table table-striped"}


