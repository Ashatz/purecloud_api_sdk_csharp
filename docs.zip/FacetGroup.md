---
title: FacetGroup
---
## .FacetGroup

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
| **Count** | **int?** |  | [optional] |
| **Items** | [**List&lt;FacetItem&gt;**](FacetItem.html) |  | [optional] |
{: class="table table-striped"}


