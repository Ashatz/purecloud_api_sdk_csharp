---
title: AggregateDataContainer
---
## ININ.PureCloudApi.Model.AggregateDataContainer

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Group** | **Dictionary&lt;string, string&gt;** | A mapping from dimension to value | [optional] |
| **Data** | [**List&lt;StatisticalResponse&gt;**](StatisticalResponse.html) |  | [optional] |
{: class="table table-striped"}


