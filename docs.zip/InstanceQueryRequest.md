---
title: InstanceQueryRequest
---
## .InstanceQueryRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **PageNumber** | **int?** |  | [optional] |
| **PageSize** | **int?** |  | [optional] |
| **Sort** | [**List&lt;SortItem&gt;**](SortItem.html) |  | [optional] |
| **Members** | [**List&lt;InstanceMemberFilter&gt;**](InstanceMemberFilter.html) |  | [optional] |
{: class="table table-striped"}


