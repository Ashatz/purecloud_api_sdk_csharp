---
title: Condition
---
## ININ.PureCloudApi.Model.Condition

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Type** | **string** |  | [optional] |
| **Inverted** | **bool?** |  | [optional] [default to false]|
| **AttributeName** | **string** |  | [optional] |
| **Value** | **string** |  | [optional] |
| **ValueType** | **string** |  | [optional] |
| **_Operator** | **string** |  | [optional] |
| **Codes** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


