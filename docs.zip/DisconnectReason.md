---
title: DisconnectReason
---
## ININ.PureCloudApi.Model.DisconnectReason

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Type** | **string** |  | [optional] |
| **Code** | **int?** |  | [optional] |
| **Phrase** | **string** |  | [optional] |
{: class="table table-striped"}


