---
title: DialerRule
---
## ININ.PureCloudApi.Model.DialerRule

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **Order** | **int?** |  | [optional] |
| **Category** | **string** |  | [optional] |
| **Conditions** | [**List&lt;Condition&gt;**](Condition.html) |  | [optional] |
| **Actions** | [**List&lt;DialerAction&gt;**](DialerAction.html) |  | [optional] |
{: class="table table-striped"}


