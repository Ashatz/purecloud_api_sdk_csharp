---
title: DialerCall
---
## .DialerCall

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **CallId** | **string** |  | [optional] |
| **ConversationId** | **string** |  | [optional] |
{: class="table table-striped"}


