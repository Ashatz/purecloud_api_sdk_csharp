---
title: Entry
---
## ININ.PureCloudApi.Model.Entry

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Value** | **string** |  | [optional] |
| **Count** | **int?** |  | [optional] |
{: class="table table-striped"}


