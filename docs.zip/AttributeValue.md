---
title: AttributeValue
---
## .AttributeValue

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Attribute** | [**WorkspaceAttribute**](WorkspaceAttribute.html) |  | [optional] |
| **Values** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


