---
title: ColumnCollapse
---
## ININ.PureCloudApi.Model.ColumnCollapse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Label** | **string** |  | [optional] |
| **Columns** | **List&lt;int?&gt;** |  | [optional] |
{: class="table table-striped"}


