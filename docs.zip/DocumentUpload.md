---
title: DocumentUpload
---
## ININ.PureCloudApi.Model.DocumentUpload

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
| **Workspace** | [**UriReference**](UriReference.html) |  | [optional] |
| **Tags** | **List&lt;string&gt;** |  | [optional] |
| **TagIds** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


