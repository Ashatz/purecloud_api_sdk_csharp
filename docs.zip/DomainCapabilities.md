---
title: DomainCapabilities
---
## ININ.PureCloudApi.Model.DomainCapabilities

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Enabled** | **bool?** |  | [optional] [default to false]|
| **Dhcp** | **bool?** |  | [optional] [default to false]|
| **Metric** | **int?** |  | [optional] |
{: class="table table-striped"}


