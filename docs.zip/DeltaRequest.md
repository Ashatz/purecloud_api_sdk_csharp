---
title: DeltaRequest
---
## ININ.PureCloudApi.Model.DeltaRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ContextToken** | **string** |  | [optional] |
{: class="table table-striped"}


