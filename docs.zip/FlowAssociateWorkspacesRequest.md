---
title: FlowAssociateWorkspacesRequest
---
## .FlowAssociateWorkspacesRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Workspaces** | **List&lt;string&gt;** | The list of Workspaces to associate with a flow.  Can be null/empty to remove associations. | |
{: class="table table-striped"}


