---
title: FlowInputData
---
## ININ.PureCloudApi.Model.FlowInputData

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **LinkedDocumentIds** | **List&lt;string&gt;** | A list of document IDs to link with the new flow instance. | [optional] |
{: class="table table-striped"}


