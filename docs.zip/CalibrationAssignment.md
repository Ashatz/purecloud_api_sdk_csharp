---
title: CalibrationAssignment
---
## ININ.PureCloudApi.Model.CalibrationAssignment

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Calibrator** | [**User**](User.html) |  | [optional] |
| **Evaluators** | [**List&lt;User&gt;**](User.html) |  | [optional] |
| **EvaluationForm** | [**EvaluationForm**](EvaluationForm.html) |  | [optional] |
| **ExpertEvaluator** | [**User**](User.html) |  | [optional] |
{: class="table table-striped"}


