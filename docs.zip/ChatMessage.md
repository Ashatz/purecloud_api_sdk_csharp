---
title: ChatMessage
---
## ININ.PureCloudApi.Model.ChatMessage

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Body** | **string** |  | [optional] |
| **Id** | **string** |  | [optional] |
| **To** | **string** |  | [optional] |
| **From** | **string** |  | [optional] |
| **Utc** | **string** |  | [optional] |
| **Chat** | **string** |  | [optional] |
| **Message** | **string** |  | [optional] |
| **Type** | **string** |  | [optional] |
| **User** | [**ChatMessageUser**](ChatMessageUser.html) |  | [optional] |
{: class="table table-striped"}


