---
title: DataValueInfo
---
## ININ.PureCloudApi.Model.DataValueInfo

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **DataItems** | [**List&lt;DataItem&gt;**](DataItem.html) |  | [optional] |
{: class="table table-striped"}


