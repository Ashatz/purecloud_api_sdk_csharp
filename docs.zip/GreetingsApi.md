# ININ.PureCloudApi.Api.GreetingsApi

All URIs are relative to *https://api.mypurecloud.com*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**DeleteGreetingId**](GreetingsApi.md#deletegreetingid) | **DELETE** /api/v2/greetings/{greetingId} | Deletes a Greeting with the given GreetingId |
| [**GetDefaults**](GreetingsApi.md#getdefaults) | **GET** /api/v2/greetings/defaults | Get an Organization&#39;s DefaultGreetingList |
| [**GetGreetingId**](GreetingsApi.md#getgreetingid) | **GET** /api/v2/greetings/{greetingId} | Get a Greeting with the given GreetingId |
| [**GetGreetingIdMedia**](GreetingsApi.md#getgreetingidmedia) | **GET** /api/v2/greetings/{greetingId}/media | Get media playback URI for this greeting |
| [**GetGreetings**](GreetingsApi.md#getgreetings) | **GET** /api/v2/greetings | Gets an Organization&#39;s Greetings |
| [**GetUserIdGreetings**](GreetingsApi.md#getuseridgreetings) | **GET** /api/v2/users/{userId}/greetings | Get a list of the User&#39;s Greetings |
| [**GetUserIdGreetingsDefaults**](GreetingsApi.md#getuseridgreetingsdefaults) | **GET** /api/v2/users/{userId}/greetings/defaults | Grabs the list of Default Greetings given a User&#39;s ID |
| [**PostGreetings**](GreetingsApi.md#postgreetings) | **POST** /api/v2/greetings | Create a Greeting for an Organization |
| [**PostUserIdGreetings**](GreetingsApi.md#postuseridgreetings) | **POST** /api/v2/users/{userId}/greetings | Creates a Greeting for a User |
| [**PutDefaults**](GreetingsApi.md#putdefaults) | **PUT** /api/v2/greetings/defaults | Update an Organization&#39;s DefaultGreetingList |
| [**PutGreetingId**](GreetingsApi.md#putgreetingid) | **PUT** /api/v2/greetings/{greetingId} | Updates the Greeting with the given GreetingId |
| [**PutUserIdGreetingsDefaults**](GreetingsApi.md#putuseridgreetingsdefaults) | **PUT** /api/v2/users/{userId}/greetings/defaults | Updates the DefaultGreetingList of the specified User |
{: class="table table-striped"}

<a name="DeleteGreetingId"></a>
## [**Greeting**](Greeting.html) DeleteGreetingId (string greetingId)

Deletes a Greeting with the given GreetingId



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class DeleteGreetingIdExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var greetingId = greetingId_example;  // string | Greeting ID

            try
            {
                // Deletes a Greeting with the given GreetingId
                Greeting result = apiInstance.DeleteGreetingId(greetingId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.DeleteGreetingId: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **greetingId** | **string**| Greeting ID |  |
{: class="table table-striped"}

### Return type

[**Greeting**](Greeting.md)

<a name="GetDefaults"></a>
## [**DefaultGreetingList**](DefaultGreetingList.html) GetDefaults ()

Get an Organization's DefaultGreetingList



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class GetDefaultsExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();

            try
            {
                // Get an Organization's DefaultGreetingList
                DefaultGreetingList result = apiInstance.GetDefaults();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.GetDefaults: " + e.Message );
            }
        }
    }
}
~~~

### Parameters
This endpoint does require any parameters.
{: class="table table-striped"}

### Return type

[**DefaultGreetingList**](DefaultGreetingList.md)

<a name="GetGreetingId"></a>
## [**Greeting**](Greeting.html) GetGreetingId (string greetingId)

Get a Greeting with the given GreetingId



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class GetGreetingIdExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var greetingId = greetingId_example;  // string | Greeting ID

            try
            {
                // Get a Greeting with the given GreetingId
                Greeting result = apiInstance.GetGreetingId(greetingId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.GetGreetingId: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **greetingId** | **string**| Greeting ID |  |
{: class="table table-striped"}

### Return type

[**Greeting**](Greeting.md)

<a name="GetGreetingIdMedia"></a>
## [**GreetingMediaInfo**](GreetingMediaInfo.html) GetGreetingIdMedia (string greetingId, string formatId = null)

Get media playback URI for this greeting



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class GetGreetingIdMediaExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var greetingId = greetingId_example;  // string | Greeting ID
            var formatId = formatId_example;  // string | The desired format (WAV, etc.) (optional)  (default to WAV)

            try
            {
                // Get media playback URI for this greeting
                GreetingMediaInfo result = apiInstance.GetGreetingIdMedia(greetingId, formatId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.GetGreetingIdMedia: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **greetingId** | **string**| Greeting ID |  |
| **formatId** | **string**| The desired format (WAV, etc.) | [optional] [default to WAV] |
{: class="table table-striped"}

### Return type

[**GreetingMediaInfo**](GreetingMediaInfo.md)

<a name="GetGreetings"></a>
## [**DomainEntityListing**](DomainEntityListing.html) GetGreetings (int? pageSize = null, int? pageNumber = null)

Gets an Organization's Greetings



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class GetGreetingsExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var pageSize = 56;  // int? | Page size (optional)  (default to 25)
            var pageNumber = 56;  // int? | Page number (optional)  (default to 1)

            try
            {
                // Gets an Organization's Greetings
                DomainEntityListing result = apiInstance.GetGreetings(pageSize, pageNumber);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.GetGreetings: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **pageSize** | **int?**| Page size | [optional] [default to 25] |
| **pageNumber** | **int?**| Page number | [optional] [default to 1] |
{: class="table table-striped"}

### Return type

[**DomainEntityListing**](DomainEntityListing.md)

<a name="GetUserIdGreetings"></a>
## [**DomainEntityListing**](DomainEntityListing.html) GetUserIdGreetings (string userId, int? pageSize = null, int? pageNumber = null)

Get a list of the User's Greetings



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class GetUserIdGreetingsExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var userId = userId_example;  // string | User ID
            var pageSize = 56;  // int? | Page size (optional)  (default to 25)
            var pageNumber = 56;  // int? | Page number (optional)  (default to 1)

            try
            {
                // Get a list of the User's Greetings
                DomainEntityListing result = apiInstance.GetUserIdGreetings(userId, pageSize, pageNumber);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.GetUserIdGreetings: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **userId** | **string**| User ID |  |
| **pageSize** | **int?**| Page size | [optional] [default to 25] |
| **pageNumber** | **int?**| Page number | [optional] [default to 1] |
{: class="table table-striped"}

### Return type

[**DomainEntityListing**](DomainEntityListing.md)

<a name="GetUserIdGreetingsDefaults"></a>
## [**DefaultGreetingList**](DefaultGreetingList.html) GetUserIdGreetingsDefaults (string userId)

Grabs the list of Default Greetings given a User's ID



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class GetUserIdGreetingsDefaultsExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var userId = userId_example;  // string | User ID

            try
            {
                // Grabs the list of Default Greetings given a User's ID
                DefaultGreetingList result = apiInstance.GetUserIdGreetingsDefaults(userId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.GetUserIdGreetingsDefaults: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **userId** | **string**| User ID |  |
{: class="table table-striped"}

### Return type

[**DefaultGreetingList**](DefaultGreetingList.md)

<a name="PostGreetings"></a>
## [**DefaultGreetingList**](DefaultGreetingList.html) PostGreetings (Greeting body)

Create a Greeting for an Organization



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class PostGreetingsExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var body = new Greeting(); // Greeting | The Greeting to create

            try
            {
                // Create a Greeting for an Organization
                DefaultGreetingList result = apiInstance.PostGreetings(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.PostGreetings: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **body** | [**Greeting**](Greeting.md)| The Greeting to create |  |
{: class="table table-striped"}

### Return type

[**DefaultGreetingList**](DefaultGreetingList.md)

<a name="PostUserIdGreetings"></a>
## [**Greeting**](Greeting.html) PostUserIdGreetings (string userId, Greeting body)

Creates a Greeting for a User



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class PostUserIdGreetingsExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var userId = userId_example;  // string | User ID
            var body = new Greeting(); // Greeting | The Greeting to create

            try
            {
                // Creates a Greeting for a User
                Greeting result = apiInstance.PostUserIdGreetings(userId, body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.PostUserIdGreetings: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **userId** | **string**| User ID |  |
| **body** | [**Greeting**](Greeting.md)| The Greeting to create |  |
{: class="table table-striped"}

### Return type

[**Greeting**](Greeting.md)

<a name="PutDefaults"></a>
## [**DefaultGreetingList**](DefaultGreetingList.html) PutDefaults (DefaultGreetingList body)

Update an Organization's DefaultGreetingList



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class PutDefaultsExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var body = new DefaultGreetingList(); // DefaultGreetingList | The updated defaultGreetingList

            try
            {
                // Update an Organization's DefaultGreetingList
                DefaultGreetingList result = apiInstance.PutDefaults(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.PutDefaults: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **body** | [**DefaultGreetingList**](DefaultGreetingList.md)| The updated defaultGreetingList |  |
{: class="table table-striped"}

### Return type

[**DefaultGreetingList**](DefaultGreetingList.md)

<a name="PutGreetingId"></a>
## [**Greeting**](Greeting.html) PutGreetingId (string greetingId, Greeting body)

Updates the Greeting with the given GreetingId



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class PutGreetingIdExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var greetingId = greetingId_example;  // string | Greeting ID
            var body = new Greeting(); // Greeting | The updated Greeting

            try
            {
                // Updates the Greeting with the given GreetingId
                Greeting result = apiInstance.PutGreetingId(greetingId, body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.PutGreetingId: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **greetingId** | **string**| Greeting ID |  |
| **body** | [**Greeting**](Greeting.md)| The updated Greeting |  |
{: class="table table-striped"}

### Return type

[**Greeting**](Greeting.md)

<a name="PutUserIdGreetingsDefaults"></a>
## [**DefaultGreetingList**](DefaultGreetingList.html) PutUserIdGreetingsDefaults (string userId, DefaultGreetingList body)

Updates the DefaultGreetingList of the specified User



### Example
~~~csharp
using System;
using System.Diagnostics;
using ININ.PureCloudApi.Api;
using ININ.PureCloudApi.Client;
using ININ.PureCloudApi.Model;

namespace Example
{
    public class PutUserIdGreetingsDefaultsExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: PureCloud Auth
            Configuration.Default.AccessToken = 'YOUR_ACCESS_TOKEN';

            var apiInstance = new GreetingsApi();
            var userId = userId_example;  // string | User ID
            var body = new DefaultGreetingList(); // DefaultGreetingList | The updated defaultGreetingList

            try
            {
                // Updates the DefaultGreetingList of the specified User
                DefaultGreetingList result = apiInstance.PutUserIdGreetingsDefaults(userId, body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GreetingsApi.PutUserIdGreetingsDefaults: " + e.Message );
            }
        }
    }
}
~~~

### Parameters


|Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **userId** | **string**| User ID |  |
| **body** | [**DefaultGreetingList**](DefaultGreetingList.md)| The updated defaultGreetingList |  |
{: class="table table-striped"}

### Return type

[**DefaultGreetingList**](DefaultGreetingList.md)

