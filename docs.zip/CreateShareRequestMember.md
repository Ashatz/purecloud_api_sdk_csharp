---
title: CreateShareRequestMember
---
## ININ.PureCloudApi.Model.CreateShareRequestMember

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **MemberType** | **string** |  | [optional] |
| **Member** | [**MemberEntity**](MemberEntity.html) |  | [optional] |
{: class="table table-striped"}


