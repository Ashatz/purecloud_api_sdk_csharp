---
title: EmailMediaPolicy
---
## ININ.PureCloudApi.Model.EmailMediaPolicy

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Actions** | [**PolicyActions**](PolicyActions.html) | Actions applied when specified conditions are met | [optional] |
| **Conditions** | [**EmailMediaPolicyConditions**](EmailMediaPolicyConditions.html) | Conditions for when actions should be applied | [optional] |
{: class="table table-striped"}


