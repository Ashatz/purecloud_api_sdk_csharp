---
title: CoverSheet
---
## ININ.PureCloudApi.Model.CoverSheet

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Notes** | **string** | Text to be added to the coversheet | [optional] |
| **Locale** | **string** | Locale, e.g. &#x3D; en-US | [optional] |
{: class="table table-striped"}


