---
title: BackendFlowAvailableActions
---
## ININ.PureCloudApi.Model.BackendFlowAvailableActions

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **CanTerminate** | **bool?** |  | [optional] [default to false]|
{: class="table table-striped"}


