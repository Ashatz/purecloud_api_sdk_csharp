---
title: AccountManager
---
## ININ.PureCloudApi.Model.AccountManager

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **FirstName** | **string** |  | [optional] |
| **LastName** | **string** |  | [optional] |
| **Phone** | **string** |  | [optional] |
| **Email** | **string** |  | [optional] |
{: class="table table-striped"}


