---
title: HardwareRate
---
## ININ.PureCloudApi.Model.HardwareRate

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **Name** | **string** |  | [optional] |
| **Description** | **string** |  | [optional] |
| **PartNumber** | **string** |  | [optional] |
| **Rate** | [**Rate**](Rate.html) |  | [optional] |
| **SelfUri** | **string** | The URI for this object | [optional] |
{: class="table table-striped"}


