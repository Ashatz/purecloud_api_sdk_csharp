---
title: ContactAddress
---
## ININ.PureCloudApi.Model.ContactAddress

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Address1** | **string** |  | [optional] |
| **Address2** | **string** |  | [optional] |
| **City** | **string** |  | [optional] |
| **State** | **string** |  | [optional] |
| **PostalCode** | **string** |  | [optional] |
| **CountryCode** | **string** |  | [optional] |
{: class="table table-striped"}


