---
title: AuditChange
---
## ININ.PureCloudApi.Model.AuditChange

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Property** | **string** |  | [optional] |
| **Entity** | [**AuditEntityReference**](AuditEntityReference.html) |  | [optional] |
| **OldValues** | **List&lt;string&gt;** |  | [optional] |
| **NewValues** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


