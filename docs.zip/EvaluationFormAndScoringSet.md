---
title: EvaluationFormAndScoringSet
---
## ININ.PureCloudApi.Model.EvaluationFormAndScoringSet

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **EvaluationForm** | [**EvaluationForm**](EvaluationForm.html) |  | [optional] |
| **Answers** | [**EvaluationScoringSet**](EvaluationScoringSet.html) |  | [optional] |
{: class="table table-striped"}


