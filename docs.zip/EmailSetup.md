---
title: EmailSetup
---
## ININ.PureCloudApi.Model.EmailSetup

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **RootDomain** | **string** | The root PureCloud domain that all sub-domains are created from. | [optional] |
{: class="table table-striped"}


