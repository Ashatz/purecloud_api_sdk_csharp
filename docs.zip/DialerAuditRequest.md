---
title: DialerAuditRequest
---
## ININ.PureCloudApi.Model.DialerAuditRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **QueryPhrase** | **string** |  | [optional] |
| **QueryFields** | **List&lt;string&gt;** |  | [optional] |
| **Facets** | [**List&lt;AuditFacet&gt;**](AuditFacet.html) |  | [optional] |
| **Filters** | [**List&lt;AuditFilter&gt;**](AuditFilter.html) |  | [optional] |
{: class="table table-striped"}


