---
title: DurationCondition
---
## ININ.PureCloudApi.Model.DurationCondition

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **DurationTarget** | **string** |  | [optional] |
| **DurationOperator** | **string** |  | [optional] |
| **DurationRange** | **string** |  | [optional] |
{: class="table table-striped"}


