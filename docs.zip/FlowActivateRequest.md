---
title: FlowActivateRequest
---
## .FlowActivateRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Activated** | **bool?** | Change the activated state of the flow definition.  True to activate the flow definition so it can be launched, false to disable the flow. | [default to false]|
{: class="table table-striped"}


