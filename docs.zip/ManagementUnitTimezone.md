---
title: ManagementUnitTimezone
---
## ININ.PureCloudApi.Model.ManagementUnitTimezone

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Timezone** | **string** |  | [optional] |
{: class="table table-striped"}


