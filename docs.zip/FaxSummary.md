---
title: FaxSummary
---
## ININ.PureCloudApi.Model.FaxSummary

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ReadCount** | **int?** |  | [optional] |
| **UnreadCount** | **int?** |  | [optional] |
| **TotalCount** | **int?** |  | [optional] |
{: class="table table-striped"}


