---
title: Facet
---
## .Facet

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
| **Type** | **string** |  | [optional] |
{: class="table table-striped"}


