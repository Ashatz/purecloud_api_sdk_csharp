---
title: FacetInfo
---
## ININ.PureCloudApi.Model.FacetInfo

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Name** | **string** |  | [optional] |
| **Entries** | [**List&lt;Entry&gt;**](Entry.html) |  | [optional] |
{: class="table table-striped"}


