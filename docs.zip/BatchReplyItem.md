---
title: BatchReplyItem
---
## ININ.PureCloudApi.Model.BatchReplyItem

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Code** | **double?** |  | [optional] |
| **Error** | **string** |  | [optional] |
| **Body** | [**BatchItemBody**](BatchItemBody.html) |  | [optional] |
{: class="table table-striped"}


