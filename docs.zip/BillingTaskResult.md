---
title: BillingTaskResult
---
## ININ.PureCloudApi.Model.BillingTaskResult

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **Name** | **string** |  | [optional] |
| **TaskType** | **string** |  | [optional] |
| **Status** | **string** |  | [optional] |
| **ResultId** | **string** |  | [optional] |
| **ResultUri** | **string** |  | [optional] |
| **ResultDownloadUrl** | **string** |  | [optional] |
| **ErrorCode** | **string** |  | [optional] |
| **SelfUri** | **string** | The URI for this object | [optional] |
{: class="table table-striped"}


