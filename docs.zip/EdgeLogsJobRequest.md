---
title: EdgeLogsJobRequest
---
## ININ.PureCloudApi.Model.EdgeLogsJobRequest

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Path** | **string** |  | [optional] |
| **Query** | **string** |  | [optional] |
| **Recurse** | **bool?** |  | [optional] [default to false]|
{: class="table table-striped"}


