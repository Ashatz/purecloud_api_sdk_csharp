---
title: ObservationQueryResponse
---
## ININ.PureCloudApi.Model.ObservationQueryResponse

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Results** | [**List&lt;ObservationDataContainer&gt;**](ObservationDataContainer.html) |  | [optional] |
{: class="table table-striped"}


