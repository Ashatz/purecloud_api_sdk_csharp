---
title: ChatMediaPolicy
---
## ININ.PureCloudApi.Model.ChatMediaPolicy

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Actions** | [**PolicyActions**](PolicyActions.html) | Actions applied when specified conditions are met | [optional] |
| **Conditions** | [**ChatMediaPolicyConditions**](ChatMediaPolicyConditions.html) | Conditions for when actions should be applied | [optional] |
{: class="table table-striped"}


