---
title: ContentAttributeFilterItem
---
## ININ.PureCloudApi.Model.ContentAttributeFilterItem

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
| **_Operator** | **string** |  | [optional] |
| **Values** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


