---
title: MaxParticipants
---
## ININ.PureCloudApi.Model.MaxParticipants

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **_MaxParticipants** | **int?** |  | [optional] |
{: class="table table-striped"}


