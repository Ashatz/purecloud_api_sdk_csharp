---
title: MediaSummary
---
## ININ.PureCloudApi.Model.MediaSummary

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ContactCenter** | [**MediaSummaryDetail**](MediaSummaryDetail.html) |  | [optional] |
| **Enterprise** | [**MediaSummaryDetail**](MediaSummaryDetail.html) |  | [optional] |
{: class="table table-striped"}


