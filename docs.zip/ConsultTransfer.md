---
title: ConsultTransfer
---
## ININ.PureCloudApi.Model.ConsultTransfer

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **SpeakTo** | **string** | Determines to whom the initiating participant is speaking. Defaults to DESTINATION | [optional] |
| **Destination** | [**Destination**](Destination.html) | Destination phone number and name. | |
{: class="table table-striped"}


