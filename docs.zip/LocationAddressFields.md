---
title: LocationAddressFields
---
## ININ.PureCloudApi.Model.LocationAddressFields

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **City** | **string** |  | [optional] |
| **Country** | **string** |  | [optional] |
| **CountryName** | **string** |  | [optional] |
| **State** | **string** |  | [optional] |
| **Street1** | **string** |  | [optional] |
| **Street2** | **string** |  | [optional] |
| **Zipcode** | **string** |  | [optional] |
{: class="table table-striped"}


