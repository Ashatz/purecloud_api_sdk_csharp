---
title: Form
---
## ININ.PureCloudApi.Model.Form

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Controls** | [**List&lt;Control&gt;**](Control.html) |  | [optional] |
{: class="table table-striped"}


