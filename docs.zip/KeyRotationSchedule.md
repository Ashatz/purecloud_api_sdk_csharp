---
title: KeyRotationSchedule
---
## ININ.PureCloudApi.Model.KeyRotationSchedule

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** | The globally unique identifier for the object. | [optional] |
| **Name** | **string** |  | [optional] |
| **Period** | **string** | Value to set schedule to | |
| **SelfUri** | **string** | The URI for this object | [optional] |
{: class="table table-striped"}


