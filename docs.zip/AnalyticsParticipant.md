---
title: AnalyticsParticipant
---
## ININ.PureCloudApi.Model.AnalyticsParticipant

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **ParticipantId** | **string** |  | [optional] |
| **ParticipantName** | **string** |  | [optional] |
| **UserId** | **string** |  | [optional] |
| **Purpose** | **string** |  | [optional] |
| **Sessions** | [**List&lt;AnalyticsSession&gt;**](AnalyticsSession.html) |  | [optional] |
{: class="table table-striped"}


