---
title: Change
---
## ININ.PureCloudApi.Model.Change

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Entity** | [**AuditEntity**](AuditEntity.html) |  | [optional] |
| **Property** | **string** |  | [optional] |
| **OldValues** | **List&lt;string&gt;** |  | [optional] |
| **NewValues** | **List&lt;string&gt;** |  | [optional] |
{: class="table table-striped"}


