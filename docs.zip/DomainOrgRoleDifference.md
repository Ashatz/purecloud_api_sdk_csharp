---
title: DomainOrgRoleDifference
---
## ININ.PureCloudApi.Model.DomainOrgRoleDifference

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **RemovedPermissionPolicies** | [**List&lt;DomainPermissionPolicy&gt;**](DomainPermissionPolicy.html) |  | [optional] |
| **AddedPermissionPolicies** | [**List&lt;DomainPermissionPolicy&gt;**](DomainPermissionPolicy.html) |  | [optional] |
| **SamePermissionPolicies** | [**List&lt;DomainPermissionPolicy&gt;**](DomainPermissionPolicy.html) |  | [optional] |
| **UserOrgRole** | [**DomainOrganizationRole**](DomainOrganizationRole.html) |  | [optional] |
| **RoleFromDefault** | [**DomainOrganizationRole**](DomainOrganizationRole.html) |  | [optional] |
{: class="table table-striped"}


