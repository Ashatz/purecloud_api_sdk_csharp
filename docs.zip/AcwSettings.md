---
title: AcwSettings
---
## ININ.PureCloudApi.Model.AcwSettings

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **WrapupPrompt** | **string** |  | [optional] |
| **TimeoutMs** | **int?** |  | [optional] |
{: class="table table-striped"}


