---
title: MemberEntity
---
## ININ.PureCloudApi.Model.MemberEntity

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Id** | **string** |  | [optional] |
{: class="table table-striped"}


