---
title: NumberDefinition
---
## .NumberDefinition

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Type** | **string** |  | [optional] |
| **MinimumValue** | **double?** |  | [optional] |
| **MaximumValue** | **double?** |  | [optional] |
| **DecimalPlaces** | **int?** |  | [optional] |
{: class="table table-striped"}


