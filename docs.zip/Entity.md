---
title: Entity
---
## ININ.PureCloudApi.Model.Entity

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **Type** | **string** |  | [optional] |
| **Id** | **string** |  | [optional] |
| **Name** | **string** |  | [optional] |
| **SelfUri** | **string** |  | [optional] |
{: class="table table-striped"}


