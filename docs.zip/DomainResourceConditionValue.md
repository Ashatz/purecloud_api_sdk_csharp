---
title: DomainResourceConditionValue
---
## ININ.PureCloudApi.Model.DomainResourceConditionValue

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **User** | [**User**](User.html) |  | [optional] |
| **Queue** | [**Queue**](Queue.html) |  | [optional] |
| **Value** | **string** |  | [optional] |
| **Type** | **string** |  | [optional] |
{: class="table table-striped"}


